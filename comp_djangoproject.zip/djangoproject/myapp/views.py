from django.shortcuts import render
from django.http import HttpResponse

def homepageview(request):
    return render(request,'home.html')

def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):
    return render(request,'contact.html')

def myform(request):
    return render(request,'myform.html')

def process(request):
    print ("welcome")
    print (request.method)
    print(request.POST)
    a=int(request.POST['txt1'])
    b=int(request.POST['txt2'])
    c=a+b
    print (c)
    return render(request,'answer.html',{'mya': a, 'myb': b,'mysum':c})

def registration(request):
   

    return render(request,'registrationform.html')

def details(request):
    print (request.method)
    print(request.POST)
    fname=str(request.POST.get('firstname'))
    mname=str(request.POST.get('middlename'))
    lname=str(request.POST.get('lastname'))
    phnum=str(request.POST.get('phonenumber'))
    address=str(request.POST.get('address'))
    email=str(request.POST.get('email'))
    password=str(request.POST.get('pass'))
    repassword=str(request.POST.get('repass'))



    
    return render(request,'details.html',{'firstname' :fname, 'middlename' : mname,'lastname' : lname,
   'phonenumber' : phnum, 'address' : address , 'email' : email , 'pass' : password , 'repass' : repassword })
